package com.bd.bd_synchronize_data;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BdSynchronizeDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(BdSynchronizeDataApplication.class, args);
	}

}
