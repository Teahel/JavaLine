package com.bd.bd_synchronize_data;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BdSynchronizeDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
