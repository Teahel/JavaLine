<script setup>
import { computed, onBeforeUnmount, onMounted, ref } from 'vue'
import { BatteryCharging, Bolt, CalendarDays, CarFront, ChartNoAxesCombined, ClipboardList, Factory, House, Leaf, PanelTop, RotateCcw, SolarPanel, Waves } from 'lucide-vue-next'
import Panel from './components/Panel.vue'
import EChart from './components/EChart.vue'

const now = ref(new Date())
let timer
onMounted(() => { timer = setInterval(() => { now.value = new Date() }, 1000) })
onBeforeUnmount(() => clearInterval(timer))
const dateText = computed(() => new Intl.DateTimeFormat('zh-CN', { year: 'numeric', month: '2-digit', day: '2-digit', weekday: 'short' }).format(now.value))
const timeText = computed(() => now.value.toLocaleTimeString('zh-CN', { hour12: false }))

const axis = { axisLine: { lineStyle: { color: '#49637e' } }, axisLabel: { color: '#b8cae0', fontSize: 11 }, splitLine: { lineStyle: { color: 'rgba(66,116,153,.24)', type: 'dashed' } } }
const tooltip = { trigger: 'axis', backgroundColor: 'rgba(3,18,38,.94)', borderColor: '#1dcdf5', textStyle: { color: '#eaf9ff' } }
const carbonOption = {
  animationDuration: 1200, tooltip,
  legend: { top: 2, textStyle: { color: '#cae8f5' }, itemWidth: 16, data: ['碳排放', '目标值', '累计排放'] },
  grid: { left: 46, right: 42, top: 38, bottom: 28 },
  xAxis: { type: 'category', data: ['1月','2月','3月','4月','5月','6月','7月','8月','9月','10月','11月','12月'], ...axis },
  yAxis: [{ type: 'value', max: 500, ...axis }, { type: 'value', max: 1000, ...axis }],
  series: [
    { name: '碳排放', type: 'bar', data: [218,186,194,232,268,334,278,245,226,208,195,185], barWidth: 16, itemStyle: { color: new (Object.getPrototypeOf({}).constructor)() } },
    { name: '目标值', type: 'line', data: Array(12).fill(260), symbol: 'none', lineStyle: { color: '#ff8c22', width: 2, type: 'dashed' } },
    { name: '累计排放', type: 'line', yAxisIndex: 1, data: [110,230,355,470,560,650,705,760,805,850,900,940], symbolSize: 7, lineStyle: { color: '#9fc943', width: 3 }, itemStyle: { color: '#a7d84e' } }
  ]
}
carbonOption.series[0].itemStyle.color = { type: 'linear', x: 0, y: 0, x2: 0, y2: 1, colorStops: [{ offset: 0, color: '#39d9ff' }, { offset: 1, color: '#1685e8' }] }

const loadOption = {
  animationDuration: 1400, tooltip,
  color: ['#20e3f2', '#ffb21c', '#ab7bff', '#ff7777'],
  legend: { top: 0, left: 0, itemWidth: 18, textStyle: { color: '#c9dbee', fontSize: 11 }, data: ['市电负荷','储能负荷','光伏负荷','充电桩负荷'] },
  grid: { left: 44, right: 12, top: 48, bottom: 28 },
  xAxis: { type: 'category', boundaryGap: false, data: ['00:00','02:00','04:00','06:00','08:00','10:00','12:00','14:00','16:00','18:00','20:00','22:00','24:00'], ...axis },
  yAxis: { type: 'value', max: 5000, ...axis },
  series: [
    { name:'市电负荷', type:'line', step:'middle', symbol:'none', data:[4500,3800,4100,4600,4300,4000,4700,3900,4200,4750,4300,4500,4450] },
    { name:'储能负荷', type:'line', step:'middle', symbol:'none', data:[2900,2900,2700,2750,3000,3200,2500,2100,1500,1600,3300,2300,2500] },
    { name:'光伏负荷', type:'line', step:'middle', symbol:'none', data:[1200,1200,1200,1200,2600,1500,1350,1350,1350,1350,1350,1350,1350] },
    { name:'充电桩负荷', type:'line', step:'middle', symbol:'none', data:[2350,2350,2400,2400,2800,3100,3600,2500,2450,2450,2450,2450,2400] }
  ]
}

const photovoltaicOption = {
  animationDuration: 1200, tooltip,
  grid: { left: 46, right: 14, top: 20, bottom: 26 },
  xAxis: { type:'category', data:['1月','2月','3月','4月','5月','6月','7月','8月','9月','10月','11月','12月'], ...axis },
  yAxis: { type:'value', max:5000, ...axis },
  series: [{ type:'line', smooth:true, symbolSize:7, data:[1100,1700,2350,3000,3500,4000,4450,4650,4200,3500,2700,1950], lineStyle:{ color:'#14d9ed', width:3 }, itemStyle:{ color:'#23efff' }, areaStyle:{ color:{ type:'linear', x:0,y:0,x2:0,y2:1,colorStops:[{offset:0,color:'rgba(20,217,237,.35)'},{offset:1,color:'rgba(20,217,237,0)'}] } } }]
}

const storageOption = {
  animationDuration: 1200, tooltip, color:['#19c8ff','#39e691'],
  legend:{ top:0, right:8, textStyle:{ color:'#d5e8f1' }, data:['充电','放电'] },
  grid:{ left:46,right:12,top:28,bottom:26 },
  xAxis:{ type:'category', data:['1月','2月','3月','4月','5月','6月','7月','8月','9月','10月','11月','12月'], ...axis },
  yAxis:{ type:'value', max:5000, ...axis },
  series:[
    {name:'充电',type:'bar',data:[2100,3300,3700,4200,4500,3800,2900,3500,4000,3600,2800,1900],barWidth:11},
    {name:'放电',type:'bar',data:[1850,2900,3300,3700,4100,3500,2700,3100,3600,3300,2500,1650],barWidth:11}
  ]
}

const kpis = [
  { label:'日发电收入(元)', value:'386', icon:Bolt, color:'amber' }, { label:'日节能收入(元)', value:'885', icon:Leaf, color:'green' }, { label:'日节碳量(kg)', value:'718', icon:Leaf, color:'green' },
  { label:'累计发电收入(元)', value:'197352', icon:Bolt, color:'amber' }, { label:'累计节能收入(元)', value:'440472', icon:Leaf, color:'green' }, { label:'累计节碳量(t)', value:'517', icon:Leaf, color:'green' }
]
const energy = [
  { label:'储能容量', value:'125kW/261kWh', icon:Bolt, tone:'blue' }, { label:'充电桩总容量', value:'1384kW', icon:BatteryCharging, tone:'green' },
  { label:'变压器容量', value:'XXXXkVA', icon:Factory, tone:'amber' }, { label:'光伏容量', value:'XXXXkWp', icon:SolarPanel, tone:'green' }
]
const storageMetrics = [ ['日充电量','XXXX'], ['月充电量','XXXX'], ['年充电量','154,620'], ['日放电量','XXXX'], ['月放电量','XXXX'], ['年放电量','148,300'] ]

const goHome = () => window.dispatchEvent(new CustomEvent('dashboard-home'))
const reload = () => window.location.reload()
</script>

<template>
  <main class="dashboard">
    <div class="bg" />
    <div class="shade" />
    <header class="topbar">
      <div class="top-actions left-actions">
        <button class="icon-button" title="返回首页" @click="goHome"><House :size="18" /></button>
        <span class="system-label"><PanelTop :size="17" /> 双碳驾驶舱</span>
      </div>
      <div class="main-title"><i />园区综合能源与双碳管理平台<i /></div>
      <div class="top-actions right-actions">
        <span><CalendarDays :size="15" />{{ dateText }}</span><b>{{ timeText }}</b>
        <button class="icon-button" title="刷新页面" @click="reload"><RotateCcw :size="17" /></button>
      </div>
    </header>

    <div class="screen-grid">
      <aside class="column left-column">
        <Panel title="综合能耗" :icon="ClipboardList" class="energy-panel">
          <div class="energy-summary"><span>本月用电量（度）：<b>XXXX</b></span><span>本月用水（吨）：<b>XXXX</b></span><span>本月用气（kWh）：<b>XXXX</b></span><span>本月用气（m³）：<b>XXXX</b></span></div>
          <div class="energy-grid"><article v-for="item in energy" :key="item.label" :class="['energy-card', item.tone]"><component :is="item.icon" :size="30"/><div><strong>{{ item.value }}</strong><span>{{ item.label }}</span></div></article></div>
        </Panel>
        <Panel title="碳排放趋势（月度）" :icon="ChartNoAxesCombined" unit="单位：tCO₂e" class="carbon-panel"><EChart :option="carbonOption" /></Panel>
        <Panel title="负荷曲线" :icon="Waves" unit="单位：kWh" class="load-panel"><EChart :option="loadOption" /></Panel>
      </aside>

      <section class="center-stage">
        <div class="kpi-grid">
          <article v-for="item in kpis" :key="item.label" :class="['kpi', item.color]"><span class="kpi-icon"><component :is="item.icon" :size="32" /></span><div><label>{{ item.label }}</label><strong>{{ item.value }}</strong></div></article>
        </div>
        <div class="scene-caption"><span>智慧园区</span><small>绿色 · 低碳 · 高效</small></div>
      </section>

      <aside class="column right-column">
        <Panel title="光伏运行" :icon="SolarPanel" class="pv-panel">
          <div class="three-metrics"><div><span>日发电量</span><b>1,234 <small>kWh</small></b></div><div><span>月发电量</span><b>36,548 <small>kWh</small></b></div><div><span>年发电量</span><b>382,188 <small>kWh</small></b></div></div>
          <h3 class="chart-subtitle">光伏月发电曲线(kWh)</h3><EChart :option="photovoltaicOption" />
        </Panel>
        <Panel title="储能运行" :icon="BatteryCharging" class="storage-panel">
          <div class="storage-metrics"><div v-for="m in storageMetrics" :key="m[0]"><span>{{ m[0] }}</span><b>{{ m[1] }} <small>kWh</small></b></div></div>
          <h3 class="chart-subtitle">今年月度充放电量对比图（kWh）</h3><EChart :option="storageOption" />
        </Panel>
        <Panel title="充电桩运行" :icon="CarFront" class="charger-panel">
          <div class="charger-content"><div class="charge-ring"><div><Bolt :size="25"/><strong>有序充电</strong></div></div><div class="charge-legend"><span><i class="pink"/>充电桩负荷(kWh)</span><span><i class="lime"/>其他负荷(kWh)</span></div><div class="charger-stats"><div><span>充电功率</span><b>28kW</b></div><div><span>日充电量</span><b>168kWh</b></div><div><span>总充电量</span><b>2520kWh</b></div><div><span>日充电金额</span><b>201.6元</b></div></div></div>
        </Panel>
      </aside>
    </div>
  </main>
</template>
