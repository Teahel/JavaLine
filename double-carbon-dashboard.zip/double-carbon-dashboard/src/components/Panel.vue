<script setup>
defineProps({ title: String, icon: Object, unit: String })
</script>

<template>
  <section class="panel">
    <header class="panel-title">
      <span class="title-icon"><component :is="icon" :size="20" /></span>
      <h2>{{ title }}</h2>
      <span v-if="unit" class="panel-unit">{{ unit }}</span>
    </header>
    <div class="panel-body"><slot /></div>
  </section>
</template>
