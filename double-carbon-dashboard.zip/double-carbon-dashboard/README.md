# 园区综合能源与双碳管理平台

基于 Vue 3、Vite、ECharts 实现的 1920×1080 可视化大屏。

## 启动

```bash
npm install
npm run dev
```

生产构建：

```bash
npm run build
```

## 数据接入

页面演示数据集中在 `src/App.vue` 中。实际开发时，可将 `kpis`、`energy`、`storageMetrics` 及各 ECharts `option` 的 `data` 替换为后端接口返回值。

页面左上“首页”按钮会触发 `dashboard-home` 浏览器事件，可按项目路由替换为 `router.push('/')`。
